# system.py
# Misst den Pico selbst, nicht die Umwelt - bewusst getrennt von sensors.py.
# Wird von der System-Seite in display.py und spaeter vom Webserver genutzt.

import gc
import os
import machine

_RESET_CAUSE_NAMES = (
    ("PWRON_RESET", "Power-On"),
    ("HARD_RESET", "Hard-Reset"),
    ("WDT_RESET", "Watchdog"),
    ("DEEPSLEEP_RESET", "Deep-Sleep"),
    ("SOFT_RESET", "Soft-Reset"),
)
_RESET_CAUSES = {}
for _name, _label in _RESET_CAUSE_NAMES:
    if hasattr(machine, _name):
        _RESET_CAUSES[getattr(machine, _name)] = _label


class SystemStats:
    """Haelt den ueber die Laufzeit beobachteten RAM-Tiefstand fest.
    Session-basiert, wie die Sensor-Min/Max-Werte - kein Flash-Verschleiss."""

    def __init__(self):
        self.mem_free_min = None

    def sample(self):
        gc.collect()
        free = gc.mem_free()
        if self.mem_free_min is None or free < self.mem_free_min:
            self.mem_free_min = free
        return free


def reset_cause():
    return _RESET_CAUSES.get(machine.reset_cause(), "unbekannt")


def flash_free_kb():
    try:
        st = os.statvfs("/")
        return (st[0] * st[3]) // 1024
    except Exception:
        return None


def firmware_info():
    u = os.uname()
    return "{} {}".format(u.sysname, u.release)


def wlan_rssi(wlan):
    """wlan: aktives network.WLAN(STA_IF) oder None, falls nicht verbunden."""
    if wlan is None or not wlan.isconnected():
        return None
    try:
        return wlan.status("rssi")
    except Exception:
        return None
