# PicoEnviro+ - Installationshinweise

## Dateien -> Pico
Alle `.py`-Dateien direkt ins Wurzelverzeichnis des Pico kopieren
(z.B. per Thonny), keine Unterordner:

    secrets.py   (nicht in diesem Paket - deine vorhandene Datei behalten)
    config.py
    sensors.py
    system.py
    wifi.py
    history.py
    web.py
    display.py
    main.py

## Voraussetzung: Firmware
Pimoroni-MicroPython fuer Pico W (getestet mit picow v1.29.0-2). Die bringt
`picographics`, `pimoroni`, `pimoroni_i2c`, `breakout_bme68x` und
`breakout_ltr559` mit - diese Bibliotheken sind NICHT Teil dieses Pakets.
Diese Firmware kennt nur die Bitmap-Fonts `bitmap6`, `bitmap8`,
`bitmap14_outline`.

## Hardware (per REPL bestaetigt)
- BME688 auf I2C 0x77 (GP4/GP5), LTR-559 auf demselben Bus
- RGB-LED: R=GP6, G=GP7, B=GP10 (nicht GP8 wie im Schaltplan-PDF)
- Mikrofon auf ADC0 = GP26

## Tasten
- A: Backlight an/aus (Auto-Off nach 2 min Inaktivitaet)
- B: WLAN an/aus. Nach erfolgreicher Verbindung startet der Webserver
  automatisch - IP steht auf der WLAN-Seite.
- X / Y: naechste / vorige Seite

## Watchdog
`WDT_TIMEOUT_MS = 0` waehrend der Entwicklung mit Thonny. Erst scharf
schalten (max. 8388 ms auf dem RP2040), wenn das Geraet eigenstaendig laeuft.

## Aenderungen Paket 1 (2026-09-23) - keine Neukalibrierung noetig
- Framebuffer PEN_P4 statt RGB332: 28,8 kB statt 57,6 kB Heap.
- Display wird vor web.py angelegt (sauberer Heap fuer den grossen Block).
- web.py: HTML-Vorlage nach dem Bauen freigegeben (~11 kB), Sende-Timeout
  2 s (verschwundener Client friert die Schleife nicht mehr ein),
  Zustand wird nur noch bei /data-Anfragen gebaut.
- main.py: abgeleitete Werte einmal pro Messung statt pro Schleifenrunde;
  BME688-Lesefehler brechen die Schleife nicht mehr ab.
- Mikrofon rechnet mit Ganzzahlen (kein Float-Muell mehr auf dem Heap).
- IAQ-Baseline lernt nur noch aus Messungen mit gueltigem Gaswert.
- Neue Diagnose: "Groesster Block/Min" auf der System-Seite und im
  Web-Footer - zeigt Heap-Fragmentierung, die mem_free() verbirgt.
- Umlaute und Grad-Zeichen auf Display und Webseite.

## Paket 2 (2026-09-26) - aendert Messwerte
Geaendert: `iaq.py` (neu), `config.py`, `main.py`, `sensors.py`,
`history.py`, `web.py`.
- Gemeinsames IAQ-Modul `iaq.py` (identisch in beiden Projekten):
  Zerfall nach Zeit (Halbwertszeit 6 h) statt pro Messung; Mindestspanne
  als Verhaeltnis hi/lo >= 2,0 - gleichbleibende Luft zeigt "gut" statt
  "kalibriert..."; 20 min Aufwaermphase nach dem Start (kalter Heizer
  verdarb frueher die Baseline); Baseline auf Flash (iaq_baseline.txt,
  alle 5 min). Simulation: 4 h konstante Luft -> 1 Labelwechsel (vorher
  rund 2.200/h beim BME690), Gas -20 % -> maessig, -60 % -> sehr schlecht.
- Messtakt 3 s statt 1 s (weniger Heizerwaerme, ruhigere Feuchte).
  ACHTUNG: aendert die Eigenerwaermung -> Temperatur-Offset am neuen
  Standort neu abgleichen (bis dahin liest das Geraet etwas zu niedrig).
- Diagramme mit Mindestskala (Temp 1 C, Feuchte 4 %, Druck 2 hPa) - keine
  Rechteck-Kurven mehr durch aufgeblasene 0,1-C-Spruenge.
- `/history` wird stueckweise gesendet (je ca. 100-140 Byte statt eines
  3-4-kB-Blocks plus Kopie) - entschaerft die Heap-Fragmentierung.
- Druckverlauf mit einer Nachkommastelle.
- iaq_baseline.txt bleibt kompatibel. Nach dem Umzug in die Kueche bei
  GESTOPPTEM Programm loeschen, damit die Baseline neu lernt.

## WLAN-Autostart (2026-09-25)
Neue, auskommentierte Zeile `# WIFI_AUTOSTART = True` in config.py
(gleich wie beim BME690). Einkommentiert geht das WLAN beim Start an.

## WLAN-Angleich (2026-09-25)
Geaendert: `wifi.py` (neu), `main.py`, `display.py`, `config.py`.
Gleiches Verhalten wie beim BME690:
- Linkpruefung jede Sekunde; Linkverlust (z. B. WLAN-Zeitschaltung der
  Fritzbox) schliesst den Webserver und startet die Neuverbindung.
- Neuer Versuch alle 15 s; nach 3 Fehlversuchen Schnittstelle komplett
  aus/an (entspricht zweimal Taste B).
- Rueckkehr oder neue IP oeffnet automatisch einen frischen Server-Socket.
- Fehlversuche stehen in der REPL; Display zeigt statt "LINK?" den Grund:
  NOAP = Netz nicht gefunden, AUTH = falsches Passwort, FAIL = abgelehnt,
  JOIN = verbindet noch, NOIP = keine IP; "OFFLINE" = WLAN per Taste aus.
- Laendercode jetzt VOR dem Start des Funkchips (vorher danach, vermutlich
  wirkungslos); Meldung, falls er nicht greift.
- Bewusst unveraendert: Powersave des Funkchips (Firmware-Standard), weil
  TEMP_OFFSET unter diesem Waermezustand kalibriert wurde.
Hinweis: Ohne WLAN-Verbindung liegt die Temperatur ca. 1 C zu niedrig.

## Kalibrierpaket (2026-09-24)
- Ein Temperatur-Offset TEMP_OFFSET = 5.4 statt TEMP_OFFSET_ON/_OFF.
  Grundlage: drei Vergleichspunkte gegen SwitchBot und Wandsensor
  (23.09. 17:22 und 20:37, 24.09. vormittags). Die Feuchte folgt
  automatisch ueber die Magnus-Korrektur, HUMIDITY_TRIM bleibt 0.

## Bekannte offene Punkte
- Paket 2 (aendert Messwerte, braucht Neukalibrierung): 3-s-Messtakt,
  zeitbasierter IAQ-Zerfall, IAQ-Sperrfrist nach Start.
- Laeuft das Backlight laenger als etwa 20 min, liest die Temperatur zu hoch.
- MQTT/Home-Assistant bewusst noch nicht enthalten.

# EOF 2026-09-26
