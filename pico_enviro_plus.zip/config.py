# config.py
# Zentrale Konfiguration. Alles, was du beim Kalibrieren oder Umbauen anfasst,
# steht hier - nicht verstreut im Code.

# ── I2C (BME688 + LTR-559) ────────────────────────────────
# Enviro+ Pack: Breakout-Garden-Bus auf GP4/GP5.
I2C_SDA = 4
I2C_SCL = 5
BME_ADDRESS = 0x77
# Angeglichen an das BME690-Projekt (2026-09-xx), um die Gaswiderstands-
# Charakteristik zwischen beiden Geraeten vergleichbarer zu machen.
# Bibliotheks-Default waere 300 C / 100 ms - bewusst abweichend gesetzt.
BME_HEATER_TEMP_C = 320
BME_HEATER_DURATION_MS = 150
# LTR-559 hat eine feste Adresse und wird vom Treiber selbst gesetzt.

# ── Mikrofon ──────────────────────────────────────────────
# Analoges MEMS-Mic. Laut Enviro+-Schaltplan liegt MIC_OUT auf ADC0 = GP26 (bestaetigt).
MIC_ADC_PIN = 26
MIC_SAMPLES = 512        # Samples pro Pegelmessung (Burst)
MIC_FULLSCALE = 32768    # halber 16-Bit-ADC-Hub (read_u16 -> 0..65535)
MIC_DB_TRIM = 0.0        # optionaler Offset in dB, rein kosmetisch

# ── RGB-LED (oben mittig am LCD) ──────────────────────────
LED_R = 6
LED_G = 7
LED_B = 10               # per REPL-Test bestaetigt (nicht GP8 - die PDF-Text-
                          # extraktion des Schaltplans hatte hier geirrt)
LED_INVERT = True        # gemeinsame Anode -> invertiert ansteuern
LED_IAQ_BRIGHTNESS = 40  # 0..255, bewusst gedimmt fuer den IAQ-Status

# ── Buttons ───────────────────────────────────────────────
BTN_A = 12   # Backlight an/aus
BTN_B = 13   # WLAN/Webserver an/aus (mit LINK-Check)
BTN_X = 14   # naechste Seite
BTN_Y = 15   # vorige Seite

# ── Display ───────────────────────────────────────────────
BRIGHTNESS = 0.8         # Backlight-Helligkeit 0.0..1.0

# ── Kalibrierung Klima ────────────────────────────────────
# TEMP_OFFSET wird vom Rohwert ABGEZOGEN (Sensor liest durch Eigenwaerme zu hoch).
# Zwei Werte, weil das Backlight spuerbar Eigenwaerme beitraegt - bestaetigt
# durch den Nacht-Vergleich vom 2026-09-16 (~3 C Unterschied). OFF ist bislang
# nur ein einzelner Messpunkt, ON der Mittelwert von zwei Messpunkten -
# beide noch vorlaeufig, weiter beobachten.
TEMP_OFFSET_ON = 6.7    # Backlight an - Mittelwert aus 4 Vergleichen (6.6/5.6/7.4/7.1)
TEMP_OFFSET_OFF = 2.9   # Backlight aus (z.B. Nachtbetrieb)
# Feuchte wird physikalisch ueber Magnus auf die korrigierte Temperatur zurueckgerechnet
# (siehe sensors.py). HUMIDITY_TRIM ist nur die letzte empirische Feinjustage
# gegen dein Referenzgeraet (SwitchBot/Enviro+), additiv in %-Punkten.
HUMIDITY_TRIM = 0.0
# Hoehe ueber NN in Metern, fuer die Umrechnung auf Meeresspiegeldruck.
ALTITUDE = 8

# ── Idealbereiche fuer Ampel-Faerbung (nur Dashboard) ─────
# Innerhalb -> gruen, ausserhalb -> neutral/gelb.
TEMP_IDEAL = (20.0, 24.0)
HUMIDITY_IDEAL = (40.0, 60.0)
# Druck hat KEINEN Idealbereich - bewusst keine Ampel, Bewertung ueber Wettertrend.

# ── Relative IAQ-Baseline (Gaswiderstand) ─────────────────
# Gleitendes Min/Max mit langsamem Zerfall gegen Langzeitdrift.
IAQ_DECAY = 0.0001            # pro Update; kleiner = traegere Baseline
IAQ_MIN_SPAN_KOHM = 20.0      # bis diese Spanne erreicht ist: "kalibriert..."
IAQ_BASELINE_FILE = "iaq_baseline.txt"
# Score-Schwellen (0..1) fuer Label + LED-Farbe.
IAQ_GOOD = 0.66
IAQ_OK = 0.33

# ── Verlauf (Sparklines) ──────────────────────────────────
HISTORY_LEN = 180            # Punkte; 180 x 60 s = 3 h
HISTORY_INTERVAL_MS = 60000  # ein Verlaufspunkt pro Minute

# ── Takt-Intervalle (nicht blockierend) ───────────────────
SENSOR_INTERVAL_MS = 1000    # BME/LTR lesen
MIC_INTERVAL_MS = 500        # Pegel messen (nur wenn Hauptseite aktiv)
DISPLAY_INTERVAL_MS = 500    # Bildschirm neu zeichnen
INTERNAL_TEMP_INTERVAL_MS = 10000  # interne Pico-Temp, langsam wechselnd
SYSTEM_INTERVAL_MS = 2000    # RAM/Flash-Abfrage (statvfs kostet etwas)
IAQ_SAVE_INTERVAL_MS = 300000  # Baseline alle 5 min auf Flash sichern
TREND_WINDOW_MS = 600000     # 10 min Fenster fuer "+x / 10 min"-Deltas
TREND_SAMPLE_INTERVAL_MS = 30000  # Trend-Snapshot alle 30 s (20 Punkte / 10 min)
# TREND_* wird erst mit web.py gebraucht - main.py implementiert noch keinen
# Tracker dafuer, um keinen unbenutzten Code mitzuschleppen.

# ── Webserver ─────────────────────────────────────────────
WEB_PORT = 80
WEB_REFRESH_S = 5            # Auto-Reload der Messwerte im Browser
WEB_CHART_REFRESH_S = 60     # Auto-Reload der Diagramme

# ── Watchdog ──────────────────────────────────────────────
# Rebootet den Pico automatisch, falls sich die Hauptschleife aufhaengt.
# 0 = deaktiviert. Max. 8388 ms auf dem RP2040.
# WAEHREND DER ENTWICKLUNG MIT THONNY AUF 0 LASSEN: einmal erzeugt, laesst
# sich der WDT nicht mehr abschalten - "Stop" in Thonny fuettert ihn nicht
# mehr, nach TIMEOUT resettet er den Chip und Thonny meldet Verbindungsverlust.
# Erst scharf schalten (z.B. 8000), wenn das Geraet eigenstaendig laeuft.
WDT_TIMEOUT_MS = 0
