# display.py
# Zeichnet die vier Seiten und steuert die IAQ-LED. Kennt keine Sensor- oder
# Netzwerk-Interna - main.py fuellt pro Zyklus ein "data"-dict mit diesen Keys:
#
#   temp, humidity, pressure, gas_kohm          -> float
#   lux                                          -> float oder None
#   db                                            -> float (dBFS)
#   humidity_desc, pressure_desc, light_desc,
#   sound_desc                                    -> str (Praesentationslabel)
#   iaq_label, iaq_color                          -> str ("green"/"yellow"/"red"/"grey")
#   minmax: {"temp": (min,max), "humidity": ..., "pressure": ..., "gas_kohm": ...,
#            "lux": ..., "db": ...}
#   uptime                                        -> str "hh:mm:ss"
#   wifi: {"connected": bool, "ip": str, "ssid": str, "rssi": int|None,
#          "hostname": str}
#   system: {"internal_temp": float|None, "mem_free": int, "mem_free_min": int,
#            "flash_free_kb": int|None, "reset_cause": str, "firmware": str}
#
# Main-Screen zeigt nur Uptime + Kurzstatus; Details leben auf den drei
# Unterseiten - das war noetig, um die Sound-Zeile ohne Ueberlauf unterzubringen.

from picographics import PicoGraphics, DISPLAY_ENVIRO_PLUS
from pimoroni import RGBLED

import config

PAGE_MAIN, PAGE_MINMAX, PAGE_WLAN, PAGE_SYSTEM = range(4)
PAGE_COUNT = 4

_IAQ_LED_RGB = {
    "green": (0, 255, 0),
    "yellow": (255, 180, 0),
    "red": (255, 0, 0),
    "grey": (80, 80, 80),
}

HEADER_H = 48
ROW_H = 34
FOOTER_Y = 226


def describe_humidity(rh):
    lo, hi = config.HUMIDITY_IDEAL
    return "angenehm" if lo < rh < hi else "unausgeglichen"


def describe_pressure(hpa):
    if hpa < 970:
        return "Sturm"
    elif hpa < 990:
        return "Regen"
    elif hpa < 1010:
        return "Veraenderlich"
    elif hpa < 1030:
        return "Schoen"
    else:
        return "Bestaendig"


def describe_light(lux):
    if lux is None:
        return "keine Daten"
    if lux < 50:
        return "dunkel"
    elif lux < 100:
        return "gedaempft"
    elif lux < 500:
        return "hell"
    else:
        return "sehr hell"


class Display:
    def __init__(self):
        self.gfx = PicoGraphics(display=DISPLAY_ENVIRO_PLUS, rotate=0)
        self.led = RGBLED(config.LED_R, config.LED_G, config.LED_B,
                           invert=config.LED_INVERT)
        self.width, self.height = self.gfx.get_bounds()
        self.gfx.set_font("sans")
        self._make_pens()

        self.backlight_on = True
        self.gfx.set_backlight(config.BRIGHTNESS)
        self.page = PAGE_MAIN

    def _make_pens(self):
        g = self.gfx
        self.WHITE = g.create_pen(255, 255, 255)
        self.BLACK = g.create_pen(0, 0, 0)
        self.RED = g.create_pen(255, 70, 70)
        self.GREEN = g.create_pen(90, 220, 130)
        self.CYAN = g.create_pen(90, 200, 255)
        self.YELLOW = g.create_pen(230, 190, 40)
        self.GREY = g.create_pen(150, 150, 150)
        self.DARKGREY = g.create_pen(60, 60, 66)
        self.LIGHTGREY = g.create_pen(150, 150, 150)
        self.HEADER_BG = g.create_pen(15, 40, 28)
        self._iaq_pen = {
            "green": self.GREEN, "yellow": self.YELLOW,
            "red": self.RED, "grey": self.GREY,
        }

    # ── Steuerung ─────────────────────────────────────────
    def toggle_backlight(self):
        self.backlight_on = not self.backlight_on
        self.gfx.set_backlight(config.BRIGHTNESS if self.backlight_on else 0)

    def next_page(self):
        self.page = (self.page + 1) % PAGE_COUNT

    def prev_page(self):
        self.page = (self.page - 1) % PAGE_COUNT

    def set_iaq_led(self, color_key):
        if not self.backlight_on:
            self.led.set_rgb(0, 0, 0)
            return
        r, g, b = _IAQ_LED_RGB.get(color_key, _IAQ_LED_RGB["grey"])
        scale = config.LED_IAQ_BRIGHTNESS / 255.0
        self.led.set_rgb(int(r * scale), int(g * scale), int(b * scale))

    def splash(self, text):
        g = self.gfx
        g.set_pen(self.BLACK)
        g.clear()
        g.set_pen(self.RED)
        g.text(text, 4, 14, self.width, scale=0.8)
        g.update()

    # ── Zeichnen ──────────────────────────────────────────
    def draw(self, data):
        if not self.backlight_on:
            return
        g = self.gfx
        g.set_pen(self.BLACK)
        g.clear()
        if self.page == PAGE_MAIN:
            self._draw_main(data)
        elif self.page == PAGE_MINMAX:
            self._draw_minmax(data)
        elif self.page == PAGE_WLAN:
            self._draw_wlan(data)
        else:
            self._draw_system(data)
        g.update()

    def _row(self, y, value_text, desc_text, value_pen, line_dy=-4):
        g = self.gfx
        g.set_pen(value_pen)
        g.text(value_text, 4, y, self.width, scale=0.8)
        g.set_pen(self.WHITE)
        g.text(desc_text, 4, y + 16, self.width, scale=0.55)
        g.set_pen(self.DARKGREY)
        g.line(4, y + ROW_H + line_dy, self.width - 4, y + ROW_H + line_dy)

    def _draw_main(self, data):
        g = self.gfx
        g.set_pen(self.HEADER_BG)
        g.rectangle(0, 0, self.width, 40)

        temp = data.get("temp", 0.0)
        lo, hi = config.TEMP_IDEAL
        temp_pen = self.GREEN if lo <= temp <= hi else (
            self.RED if temp > hi else self.CYAN)

        g.set_pen(temp_pen)
        g.text("{:.1f}C".format(temp), 4, 18, self.width, scale=1.3)

        tmin, tmax = data.get("minmax", {}).get("temp", (None, None))
        if tmin is not None:
            g.set_pen(self.CYAN)
            g.text("min {:.1f}".format(tmin), 125, 10, self.width, scale=0.6)
            g.set_pen(self.RED)
            g.text("max {:.1f}".format(tmax), 125, 26, self.width, scale=0.6)

        y = HEADER_H
        self._row(y, "{:.0f}%".format(data.get("humidity", 0.0)),
                  data.get("humidity_desc", "-"), self.WHITE, line_dy=-8)
        y += ROW_H
        self._row(y, "{:.0f} hPa".format(data.get("pressure", 0.0)),
                  data.get("pressure_desc", "-"), self.WHITE, line_dy=-8)
        y += ROW_H
        lux = data.get("lux")
        lux_text = "{:.0f} Lux".format(lux) if lux is not None else "-- Lux"
        self._row(y, lux_text, data.get("light_desc", "-"), self.WHITE, line_dy=-8)
        y += ROW_H
        gas_pen = self._iaq_pen.get(data.get("iaq_color", "grey"), self.GREY)
        self._row(y, "{:.0f} kOhm".format(data.get("gas_kohm", 0.0)),
                  data.get("iaq_label", "-"), gas_pen, line_dy=-8)
        y += ROW_H
        self._row(y, "{:.0f} dB".format(data.get("db", 0.0)),
                  data.get("sound_desc", "-"), self.WHITE)

        online = data.get("wifi", {}).get("connected")
        prefix = "Laufzeit {} / ".format(data.get("uptime", "--:--:--"))
        status = "ONLINE" if online else "LINK?"

        g.set_pen(self.LIGHTGREY)
        g.text(prefix, 4, FOOTER_Y, self.width, scale=0.5)
        prefix_w = g.measure_text(prefix, scale=0.5)
        g.set_pen(self.GREEN if online else self.RED)
        g.text(status, 4 + prefix_w, FOOTER_Y, self.width, scale=0.5)

    def _kv_page(self, title, rows):
        """rows: Liste aus (label, value_text, value_pen)."""
        g = self.gfx
        g.set_pen(self.CYAN)
        g.text(title, 4, 16, self.width, scale=0.9)
        y = 34
        for label, value_text, value_pen in rows:
            g.set_pen(self.LIGHTGREY)
            g.text(label, 4, y, self.width, scale=0.55)
            g.set_pen(value_pen)
            g.text(value_text, 4, y + 14, self.width, scale=0.8)
            g.set_pen(self.DARKGREY)
            g.line(4, y + 26, self.width - 4, y + 26)
            y += 34

    def _draw_minmax(self, data):
        mm = data.get("minmax", {})

        def fmt(key, unit, decimals=1):
            lo, hi = mm.get(key, (None, None))
            if lo is None:
                return "-- / -- {}".format(unit)
            f = "{{:.{}f}}".format(decimals)
            return (f + " / " + f + " {}").format(lo, hi, unit)

        rows = [
            ("Luftdruck", fmt("pressure", "hPa", 0), self.WHITE),
            ("Luftfeuchte", fmt("humidity", "%", 0), self.WHITE),
            ("Wettertrend", data.get("pressure_desc", "--"), self.WHITE),
            ("Gaswiderstand", fmt("gas_kohm", "kOhm", 0), self.WHITE),
            ("Licht", fmt("lux", "Lux", 0), self.WHITE),
            ("Geraeuschpegel", fmt("db", "dB", 0), self.WHITE),
        ]
        self._kv_page("Min/Max", rows)

    def _draw_wlan(self, data):
        wifi = data.get("wifi", {})
        connected = wifi.get("connected", False)
        status_pen = self.GREEN if connected else self.RED
        rssi = wifi.get("rssi")
        rssi_text = "{} dBm".format(rssi) if rssi is not None else "--"

        rows = [
            ("Status", "ONLINE" if connected else "LINK?", status_pen),
            ("SSID", wifi.get("ssid") or "--", self.WHITE),
            ("IP-Adresse", wifi.get("ip") or "--", self.WHITE),
            ("Signal", rssi_text, self.WHITE),
            ("Hostname", wifi.get("hostname") or "--", self.WHITE),
        ]
        self._kv_page("WLAN", rows)
        g = self.gfx
        g.set_pen(self.LIGHTGREY)
        g.text("Taste B: WLAN an/aus", 4, FOOTER_Y, self.width, scale=0.5)

    def _draw_system(self, data):
        sysinfo = data.get("system", {})
        it = sysinfo.get("internal_temp")
        it_text = "{:.0f} C (grob)".format(it) if it is not None else "--"
        mem_free = sysinfo.get("mem_free")
        mem_min = sysinfo.get("mem_free_min")
        if mem_free is not None:
            mem_text = "{:.1f} / {:.1f} kB".format(
                mem_free / 1024, (mem_min if mem_min is not None else mem_free) / 1024)
        else:
            mem_text = "--"
        flash_kb = sysinfo.get("flash_free_kb")
        flash_text = "{} kB frei".format(flash_kb) if flash_kb is not None else "--"

        st_label, st_ok = sysinfo.get("selftest", ("--", None))
        st_pen = self.GREEN if st_ok is True else (
            self.RED if st_ok is False else self.WHITE)

        rows = [
            ("Pico-Temperatur", it_text, self.WHITE),
            ("RAM frei / Minimum", mem_text, self.WHITE),
            ("Flash", flash_text, self.WHITE),
            ("Reset-Ursache", sysinfo.get("reset_cause", "--"), self.WHITE),
            ("Selbsttest", st_label, st_pen),
        ]
        self._kv_page("System", rows)
