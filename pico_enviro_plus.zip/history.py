# history.py
# Zeitreihen-Verwaltung fuer main.py: kurze Trend-Deltas ("+0.3 C / 10 min")
# und der lange Ringpuffer fuer die Web-Sparklines. Getrennt von sensors.py,
# weil das hier reine Zeitverwaltung ist, keine Messung.

import time
from array import array


class Trend:
    """Delta zum aeltesten Punkt im Zeitfenster."""

    def __init__(self, window_ms, sample_ms):
        self.window_ms = window_ms
        self.sample_ms = sample_ms
        self._times = []
        self._values = []
        self._last_sample = 0

    def maybe_add(self, now, value):
        if self._times and time.ticks_diff(now, self._last_sample) < self.sample_ms:
            return
        self._last_sample = now
        self._times.append(now)
        self._values.append(value)
        while self._times and time.ticks_diff(now, self._times[0]) > self.window_ms:
            self._times.pop(0)
            self._values.pop(0)

    def delta(self):
        if len(self._values) < 2:
            return None
        span = time.ticks_diff(self._times[-1], self._times[0])
        if span < self.window_ms * 0.9:
            # Fenster noch nicht voll genug - sonst zeigt "/ 10 min" einen
            # Wert, der in Wirklichkeit nur ueber ein paar Sekunden/Minuten
            # gemessen wurde (z.B. direkt nach dem Boot).
            return None
        return self._values[-1] - self._values[0]


class History:
    """Ringpuffer je Messreihe. array('f') statt Listen - spart RAM
    (4 Werte x HISTORY_LEN Punkte x 4 Byte statt Python-Objekt-Overhead)."""

    def __init__(self, keys, length, interval_ms):
        self.length = length
        self.interval_ms = interval_ms
        self.keys = keys
        self._buf = {k: array("f", (0.0 for _ in range(length))) for k in keys}
        self._count = 0
        self._head = 0
        self._last_sample = 0

    def maybe_add(self, now, values):
        if self._count and time.ticks_diff(now, self._last_sample) < self.interval_ms:
            return
        self._last_sample = now
        for k in self.keys:
            self._buf[k][self._head] = values[k]
        self._head = (self._head + 1) % self.length
        if self._count < self.length:
            self._count += 1

    def series(self, key):
        """Werte chronologisch (aeltester zuerst) als normale Liste fuer JSON."""
        buf = self._buf[key]
        if self._count < self.length:
            return list(buf[:self._count])
        return list(buf[self._head:]) + list(buf[:self._head])
