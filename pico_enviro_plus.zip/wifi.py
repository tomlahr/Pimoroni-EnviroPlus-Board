# wifi.py
# Nicht blockierender WLAN-Zustandsautomat. connect() kehrt sofort zurueck;
# poll() prueft den Fortschritt in der Hauptschleife, ohne sie zu blockieren.
# Wird spaeter auch von web.py genutzt (derselbe WLAN-Zustand, ein Server).

import time
import network

import config
import secrets

_OFF = "off"
_CONNECTING = "connecting"
_CONNECTED = "connected"

_RETRY_MS = 15000  # nach dieser Zeit ohne Verbindung: neuer Connect-Versuch


class WiFi:
    def __init__(self):
        self.wlan = None
        self.state = _OFF
        self._connect_started = 0

    def enable(self):
        if self.wlan is None:
            self.wlan = network.WLAN(network.STA_IF)
        self.wlan.active(True)
        try:
            import rp2
            rp2.country(secrets.WIFI_COUNTRY)
        except Exception:
            pass
        try:
            self.wlan.config(hostname=secrets.WIFI_HOSTNAME)
        except Exception:
            pass
        self.wlan.connect(secrets.WIFI_SSID, secrets.WIFI_PASSWORD)
        self.state = _CONNECTING
        self._connect_started = time.ticks_ms()

    def disable(self):
        if self.wlan is not None:
            self.wlan.disconnect()
            self.wlan.active(False)
        self.state = _OFF

    def toggle(self):
        if self.state == _OFF:
            self.enable()
        else:
            self.disable()

    def poll(self):
        """Jede Schleifenrunde aufrufen - reine Statuspruefung, kein Warten."""
        if self.state != _CONNECTING or self.wlan is None:
            return
        if self.wlan.isconnected():
            self.state = _CONNECTED
        elif time.ticks_diff(time.ticks_ms(), self._connect_started) > _RETRY_MS:
            self.wlan.connect(secrets.WIFI_SSID, secrets.WIFI_PASSWORD)
            self._connect_started = time.ticks_ms()

    @property
    def enabled(self):
        return self.state != _OFF

    @property
    def connected(self):
        return self.state == _CONNECTED and self.wlan is not None \
            and self.wlan.isconnected()

    @property
    def ip(self):
        return self.wlan.ifconfig()[0] if self.connected else None

    @property
    def ssid(self):
        return secrets.WIFI_SSID if self.enabled else None
