# main.py
# Bindet sensors.py, system.py, display.py, wifi.py, history.py und web.py
# zusammen. Kein einziges time.sleep() in der Hauptschleife - jede Wartezeit
# laeuft ueber ticks_ms()-Vergleiche, damit Tasten, Webserver und Watchdog
# jederzeit reagieren.

import time
import machine
from pimoroni import Button

import config
import secrets
import sensors
import system
import display
import wifi
import history
import web


def format_uptime(boot_time):
    total = time.ticks_diff(time.ticks_ms(), boot_time) // 1000
    h, rem = divmod(total, 3600)
    m, s = divmod(rem, 60)
    return "{:02d}:{:02d}:{:02d}".format(h, m, s)


class EdgeButton:
    """Entprellter Tastendruck: feuert genau einmal pro physischem Druck,
    nicht wiederholt waehrend des Haltens. Kein time.sleep()."""

    def __init__(self, pin, debounce_ms=50):
        self.btn = Button(pin, invert=True)
        self.debounce_ms = debounce_ms
        self._was_pressed = False
        self._last_change = 0

    def pressed(self):
        now = time.ticks_ms()
        raw = self.btn.is_pressed
        if raw != self._was_pressed and \
           time.ticks_diff(now, self._last_change) > self.debounce_ms:
            self._last_change = now
            self._was_pressed = raw
            return raw  # True nur bei steigender Flanke (Tastendruck)
        return False


class MinMaxTracker:
    """Session-basiert - startet bei jedem Boot neu, wie im Display gezeigt."""

    def __init__(self):
        self._data = {}

    def update(self, key, value):
        lo, hi = self._data.get(key, (value, value))
        if value < lo:
            lo = value
        if value > hi:
            hi = value
        self._data[key] = (lo, hi)

    def as_dict(self):
        return dict(self._data)


def main():
    boot_time = time.ticks_ms()

    scr = display.Display()
    scr.splash("Warte auf Sensoren...")

    i2c = sensors.make_i2c()
    weather = sensors.Weather(i2c)
    weather.warmup()
    light = sensors.Light(i2c)
    mic = sensors.Microphone()
    itemp = sensors.InternalTemp()
    iaq = sensors.IAQBaseline()
    selftest = sensors.SelfTest()
    sysstats = system.SystemStats()
    net = wifi.WiFi()
    server = web.WebServer(config.WEB_PORT)

    btn_a = EdgeButton(config.BTN_A)  # Backlight an/aus
    btn_b = EdgeButton(config.BTN_B)  # WLAN an/aus
    btn_x = EdgeButton(config.BTN_X)  # naechste Seite
    btn_y = EdgeButton(config.BTN_Y)  # vorige Seite

    minmax = MinMaxTracker()
    hist_buf = history.History(("temp", "humidity", "pressure", "gas_kohm"),
                                config.HISTORY_LEN, config.HISTORY_INTERVAL_MS)
    trend_keys = ("temp", "humidity", "pressure", "gas_kohm")
    trends = {
        k: history.Trend(config.TREND_WINDOW_MS, config.TREND_SAMPLE_INTERVAL_MS)
        for k in trend_keys
    }

    # Statische Systemwerte einmalig ermitteln - aendern sich nicht zur Laufzeit.
    reset_cause = system.reset_cause()
    firmware = system.firmware_info()

    # Erste echte Messung vor dem Loop, damit der erste Displayaufbau und
    # die erste Webantwort keine Platzhalter zeigen.
    weather.temp_offset = config.TEMP_OFFSET_ON if scr.backlight_on else config.TEMP_OFFSET_OFF
    w = weather.read()
    iaq.update(w["gas_kohm"], w["heater_stable"])
    selftest.update(w["heater_stable"], w["gas_valid"], w["gas_kohm"])
    lux = light.read()
    db = mic.read_dbfs()
    internal_temp = itemp.read()
    flash_kb = system.flash_free_kb()
    mem_free = sysstats.sample()

    for key in trend_keys:
        minmax.update(key, w[key])
    if lux is not None:
        minmax.update("lux", lux)
    minmax.update("db", db)
    minmax.update("dewpoint", sensors.dewpoint(w["temp"], w["humidity"]))
    minmax.update("vpd_kpa", sensors.vpd_kpa(w["temp"], w["humidity"]))

    wdt = machine.WDT(timeout=config.WDT_TIMEOUT_MS) \
        if config.WDT_TIMEOUT_MS else None

    now0 = time.ticks_ms()
    last_sensor = last_mic = last_internal = last_display = 0
    last_system = last_iaq_save = now0
    was_connected = False

    while True:
        if wdt:
            wdt.feed()

        if btn_a.pressed():
            scr.toggle_backlight()
        if btn_b.pressed():
            net.toggle()
            if not net.enabled:
                server.stop()
        if btn_x.pressed():
            scr.next_page()
        if btn_y.pressed():
            scr.prev_page()

        net.poll()
        if net.connected and not was_connected:
            try:
                server.start()
            except Exception:
                pass
        was_connected = net.connected

        now = time.ticks_ms()

        if time.ticks_diff(now, last_sensor) >= config.SENSOR_INTERVAL_MS:
            last_sensor = now
            weather.temp_offset = config.TEMP_OFFSET_ON if scr.backlight_on else config.TEMP_OFFSET_OFF
            w = weather.read()
            iaq.update(w["gas_kohm"], w["heater_stable"])
            selftest.update(w["heater_stable"], w["gas_valid"], w["gas_kohm"])
            lux = light.read()
            minmax.update("temp", w["temp"])
            minmax.update("humidity", w["humidity"])
            minmax.update("pressure", w["pressure"])
            minmax.update("gas_kohm", w["gas_kohm"])
            if lux is not None:
                minmax.update("lux", lux)
            minmax.update("dewpoint", sensors.dewpoint(w["temp"], w["humidity"]))
            minmax.update("vpd_kpa", sensors.vpd_kpa(w["temp"], w["humidity"]))
            hist_buf.maybe_add(now, {
                "temp": w["temp"], "humidity": w["humidity"],
                "pressure": w["pressure"], "gas_kohm": w["gas_kohm"],
            })
            for key in trend_keys:
                trends[key].maybe_add(now, w[key])

        if time.ticks_diff(now, last_mic) >= config.MIC_INTERVAL_MS:
            last_mic = now
            db = mic.read_dbfs()
            minmax.update("db", db)

        if time.ticks_diff(now, last_internal) >= config.INTERNAL_TEMP_INTERVAL_MS:
            last_internal = now
            internal_temp = itemp.read()

        if time.ticks_diff(now, last_system) >= config.SYSTEM_INTERVAL_MS:
            last_system = now
            mem_free = sysstats.sample()
            flash_kb = system.flash_free_kb()

        if time.ticks_diff(now, last_iaq_save) >= config.IAQ_SAVE_INTERVAL_MS:
            last_iaq_save = now
            iaq.save()

        iaq_label, iaq_color = iaq.classify(w["gas_kohm"])
        iaq_score = iaq.score(w["gas_kohm"])
        scr.set_iaq_led(iaq_color)

        # Gemeinsamer Zustand fuer Display UND Webserver - eine Quelle,
        # keine doppelte Buchhaltung. Wird jede Runde neu zusammengesetzt;
        # das ist haeufiger als noetig, aber ein paar Dict-Eintraege kosten
        # auf dem RP2040 nichts Nennenswertes - Korrektheit vor Mikro-Sparsamkeit.
        state = {
            "temp": w["temp"],
            "humidity": w["humidity"],
            "pressure": w["pressure"],
            "gas_kohm": w["gas_kohm"],
            "lux": lux,
            "db": db,
            "humidity_desc": display.describe_humidity(w["humidity"]),
            "pressure_desc": display.describe_pressure(w["pressure"]),
            "light_desc": display.describe_light(lux),
            "sound_desc": mic.describe(db),
            "heater_stable": w["heater_stable"],
            "gas_valid": w["gas_valid"],
            "dewpoint": sensors.dewpoint(w["temp"], w["humidity"]),
            "vpd_kpa": sensors.vpd_kpa(w["temp"], w["humidity"]),
            "iaq_label": iaq_label,
            "iaq_color": iaq_color,
            "iaq_score": iaq_score,
            "minmax": minmax.as_dict(),
            "trend": {k: trends[k].delta() for k in trend_keys},
            "uptime": format_uptime(boot_time),
            "wifi": {
                "connected": net.connected,
                "ip": net.ip,
                "ssid": net.ssid,
                "rssi": system.wlan_rssi(net.wlan),
                "hostname": secrets.WIFI_HOSTNAME,
            },
            "system": {
                "internal_temp": internal_temp,
                "mem_free": mem_free,
                "mem_free_min": sysstats.mem_free_min,
                "flash_free_kb": flash_kb,
                "reset_cause": reset_cause,
                "firmware": firmware,
                "selftest": selftest.status(),
            },
        }

        try:
            server.poll(state, hist_buf)
        except Exception:
            pass

        if time.ticks_diff(now, last_display) >= config.DISPLAY_INTERVAL_MS:
            last_display = now
            scr.draw(state)


main()
