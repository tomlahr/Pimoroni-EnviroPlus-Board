# secrets.py
# WLAN-Zugangsdaten. Diese Datei NICHT weitergeben (kein FYI, kein Repo).
# Auf dem Pico liegt sie neben main.py im Wurzelverzeichnis.

WIFI_SSID = "DEIN_WLAN"
WIFI_PASSWORD = "DEIN_PASSWORT"

# Regulatorische Funk-Domain fuer den CYW43-Chip. DE = Deutschland.
WIFI_COUNTRY = "DE"

# Hostname, unter dem sich der Pico im Netz meldet (falls der Router mDNS/DHCP-Hostnamen zeigt).
WIFI_HOSTNAME = "picoenviro"
